
package tests;

import base.BaseTest;
import pages.LoginPage;
import utils.JsonUtil;
import utils.RetryAnalyzer;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.apache.commons.io.FileUtils;
import java.io.File;
import java.io.IOException;

public class LoginTest extends BaseTest {

    @DataProvider(name = "loginData")
    public Object[][] getData() throws IOException {
        return JsonUtil.getTestData("src/test/resources/test-data/loginData.json");
    }

    @Test(dataProvider = "loginData", retryAnalyzer = RetryAnalyzer.class)
    public void testLogin(String testCaseId, String username, String password, String expectedMessage) {
        System.out.println("Executing Test Case: " + testCaseId);
        driver.get("https://your-app-url.com/login");
        LoginPage login = new LoginPage(driver);
        login.login(username, password);

        String actualMessage = login.getStatusMessage();
        boolean testPassed = actualMessage.equals(expectedMessage);

        if (!testPassed) {
            String screenshotPath = takeScreenshot(testCaseId);
            System.out.println("Screenshot saved at: " + screenshotPath);
        } else {
            System.out.println("Test Passed");
        }

        Assert.assertEquals(actualMessage, expectedMessage);
    }

    public String takeScreenshot(String testCaseId) {
        try {
            File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            String path = "screenshots/" + testCaseId + "_" + System.currentTimeMillis() + ".png";
            File dest = new File(path);
            FileUtils.copyFile(src, dest);
            return path;
        } catch (IOException e) {
            System.out.println("Screenshot failed: " + e.getMessage());
            return null;
        }
    }
}
