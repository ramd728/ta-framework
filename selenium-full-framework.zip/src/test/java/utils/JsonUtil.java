
package utils;

import java.io.File;
import java.io.IOException;
import java.util.*;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil {
    public static Object[][] getTestData(String filePath) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        List<Map<String, String>> testData =
            mapper.readValue(new File(filePath), new TypeReference<>() {});

        return testData.stream()
            .filter(data -> Boolean.parseBoolean(data.get("run")))
            .map(data -> new Object[] {
                data.get("testCaseId"),
                data.get("username"),
                data.get("password"),
                data.get("expectedMessage")
            }).toArray(Object[][]::new);
    }
}
